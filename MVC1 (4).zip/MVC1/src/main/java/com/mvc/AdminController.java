package com.mvc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {
	adminDAO adm = new adminDAO();
	String reg_id;
	String student_name;
	String phone_no;
	String email;
	String username;
	String branch;

	@RequestMapping("/admin_login")
	public ModelAndView admin(HttpServletRequest req, HttpServletResponse res) {

		String uname = req.getParameter("u");
		String pass = req.getParameter("p");
		String result = adm.validate(uname, pass);

		ModelAndView mv = new ModelAndView();
		if (result.equals("Success")) {
			mv.setViewName("home1.jsp");
			mv.addObject("name", uname);
			return mv;
		} else if (result.equals("null")) {
			mv.setViewName("admin1.jsp");
			return mv;
		} else {
			mv.setViewName("admin1.jsp");
			return mv;
		}
	}

	@RequestMapping("/view_users")
	public ModelAndView view(HttpServletRequest req, HttpServletResponse res)
			throws SQLException, ClassNotFoundException {
//		List li = adm.viewUsers();
//
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("viewusers.jsp");
//		mv.addObject("list", li);

		List<Details> li = new ArrayList();

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false", "root", "8618");
		Statement st = con.createStatement();
		ResultSet rs1 = st.executeQuery("SELECT * FROM user_details");
		ModelAndView mv = new ModelAndView();

		while (rs1.next()) {
			Details details = new Details();
			details.setReg_id(rs1.getString(1));
			details.setStudent_name(rs1.getString(2));
			details.setBranch(rs1.getString(3));
			details.setPhone_no(rs1.getString(4));
			details.setEmail(rs1.getString(5));
			details.setUsername(rs1.getString(6));
			li.add(details);
		}
		mv.setViewName("viewusers.jsp");
		mv.addObject("list", li);
		return mv;
	}

//	add books

	@RequestMapping("/addbook")
	public ModelAndView bookRegistration(HttpServletRequest req, HttpServletResponse res) {

		String id = req.getParameter("id");
		String bname = req.getParameter("bname");
		String author = req.getParameter("author");
		String published = req.getParameter("published");
		String bname1 = adm.bookRegistration(id, bname, author, published);

		ModelAndView mv = new ModelAndView();
		if (bname1 != null) {
			mv.setViewName("viewbooks.jsp");
			mv.addObject("name", bname1);
		} else {
			mv.setViewName("viewbooks.jsp");
		}
		// mv.addObject("name", result);

		return mv;

	}

//	update books

	@RequestMapping("/updatebook")
	public ModelAndView updatebook(HttpServletRequest req, HttpServletResponse res)
			throws ClassNotFoundException, SQLException {

		ModelAndView mv = new ModelAndView();
		String id = req.getParameter("id");
		String book = req.getParameter("book");
		String author = req.getParameter("author");
		String published = req.getParameter("published");
		int i = adm.updatebook(id, book, author, published);
		if (i >= 0) {
			mv.setViewName("success.jsp");
			mv.addObject("res", "success");
		} else {
			mv.setViewName("success.jsp");
			mv.addObject("res", "fail");
		}

		return mv;

	}

	//searchbook

//	@RequestMapping("/search")
//	public ModelAndView searchBook(HttpServletRequest req, HttpServletResponse res) {
//		String id = req.getParameter("bookname");
//		String bname1 = adm.searchBook(id);
//		ModelAndView mv = new ModelAndView();
//		if (bname1 != null) {
//			mv.setViewName("searchbook.jsp");
//			System.out.println("Success");
//		} else {
//			mv.setViewName(".jsp");
//		}
//		// mv.addObject("name", result);
//		return mv;
//	}

}
