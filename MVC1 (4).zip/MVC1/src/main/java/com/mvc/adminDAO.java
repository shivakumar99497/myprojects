package com.mvc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class adminDAO {
	ResultSet rs1;

	public String validate(String uname, String pass) {

		Connection con = null;
		String password = null;
		String result = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false",
					"root", "8618");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT password FROM admin_table WHERE username='" + uname + "'");

			while (rs.next()) {
				password = rs.getString(1);

			}
			if (password == null) {
				return "null";
			}

			if (password.equals(pass)) {
				result = "Success";

			} else {
				result = "Fail";
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		System.out.println("Result  ::" + result);

		return result;
	}

//	view users dao
	List<String> li = new ArrayList();

	public List viewUsers() {
		Connection con = null;
		String password = null;
		String result = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false",
					"root", "8618");
			Statement st = con.createStatement();
			rs1 = st.executeQuery("SELECT * FROM user_details");

			while (rs1.next()) {
				String details = rs1.getString(1) + " " + rs1.getString(2);
				li.add(details);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		System.out.println("Result  ::" + result);

		return li;
	}

//	add books

	public String bookRegistration(String id, String bname, String author, String published) {

		Connection con = null;
		String result = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false",
					"root", "8618");
			Statement st = con.createStatement();
			System.out.println(
					"insert into books values('" + id + "','" + bname + "','" + author + "', '" + published + "')");
			int i = st.executeUpdate("insert into books(bookid,bookname,authorname,Published) values('" + id + "','"
					+ bname + "','" + author + "', '" + published + "')");
			System.out.println("i ::" + i);
			if (i > 0) {
				result = bname;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		System.out.println("Result ::" + result);
		return result;
	}

//	update book

	public int updatebook(String id, String book, String author, String published)
			throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false", "root", "8618");

		Statement st = con.createStatement();
		int i = st.executeUpdate("update books set bookid='" + id + "', bookname = '" + book + "', authorname='"
				+ author + "',Published = '" + published + "' where bookId='" + id + "'");

		return i;
	}

	// search book
//
//	public String searchBook(String id) {
//
//		Connection con = null;
//		String result = null;
//		try {
//
//			Class.forName("com.mysql.jdbc.Driver");
//			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false",
//					"root", "8618");
//			Statement st = con.createStatement();
//
//			ResultSet rs = st.executeQuery("select * from books where bookname='" + id + "'");
//			System.out.println("i ::" + i);
//			if (i > 0) {
//				result = id;
//			}
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} finally {
//
//			try {
//				if (con != null) {
//					con.close();
//				}
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//		}
//
//		System.out.println("Result ::" + result);
//		return result;
//
//	}

}
