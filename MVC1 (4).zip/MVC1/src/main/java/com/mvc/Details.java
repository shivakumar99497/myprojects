package com.mvc;

public class Details {
	String reg_id;
	String student_name;
	String phone_no;
	String email;
	String username;
	String branch;

	public Details(String reg_id, String student_name, String phone_no, String email, String username, String branch) {
		super();
		this.reg_id = reg_id;
		this.student_name = student_name;
		this.phone_no = phone_no;
		this.email = email;
		this.username = username;
		this.branch = branch;
	}

	public Details() {
		// TODO Auto-generated constructor stub
	}

	public String getReg_id() {
		return reg_id;
	}

	public void setReg_id(String reg_id) {
		this.reg_id = reg_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	

}
